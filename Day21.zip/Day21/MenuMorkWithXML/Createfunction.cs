﻿using System.IO;

namespace Day21.MenuMorkWithXML
{
    public static class Createfunction
    {
        public static void Create()
        {
            File.Create("id.txt");
        }
        
    }
}
